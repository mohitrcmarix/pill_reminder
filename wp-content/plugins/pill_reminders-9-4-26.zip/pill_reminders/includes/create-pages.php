<?php
// Activation pages
function pill_reminders_activate()
{
    pill_reminders_install_table();
    pill_reminders_create_page('Pill Reminder', 'pill_reminder', '[pill_reminder_shortcode]');
    pill_reminders_create_page('Add Pill Reminder', 'add_pill_reminder', '[add_pill_reminder_shortcode]');
    pill_reminders_create_page('Pill Reminder Details', 'pill_reminder_details', '[pill_reminder_details_shortcode]');
    pill_reminders_create_page('View Pill Reminder', 'view_pill_reminder', '[view_pill_reminder_shortcode]');
    pill_reminders_create_page('Sign-In','sign-in','[sign-in_shortcode]');
    pill_reminders_create_page('Sign-Up','Sign-Up','[sign-up_shortcode]');

    pill_reminders_create_primary_menu_with_all_pages();
    flush_rewrite_rules();
}

function pill_reminders_create_page($title, $slug, $shortcode)
{
    if (!get_page_by_path($slug)) {
        wp_insert_post([
            'post_title' => $title,
            'post_name' => $slug,
            'post_content' => $shortcode,
            'post_status' => 'publish',
            'post_type' => 'page',
            'post_author' => 1,
        ]);
    }
}

// ====================== SHORTCODES ======================
add_shortcode('pill_reminder_shortcode', 'pill_reminders_page_content');
function pill_reminders_page_content()
{
    ob_start();
    require plugin_dir_path(__FILE__) . '../templates/home.php';
    return home();
}

add_shortcode('add_pill_reminder_shortcode', 'render_add_pill_page');

function render_add_pill_page()
{
    ob_start();
    include plugin_dir_path(__FILE__) . '../templates/add_pill_reminder.php';
    return add_pill_reminder();
}


add_shortcode('pill_reminder_details_shortcode', 'render_pill_reminder_details_page');
function render_pill_reminder_details_page()
{
    ob_start();
    require plugin_dir_path(__FILE__) . '../templates/pill_reminder_details.php';
    return pill_reminder_details();
}

add_shortcode('view_pill_reminder_shortcode', 'render_view_pill_reminder_page');
function render_view_pill_reminder_page()
{
    ob_start();
    require plugin_dir_path(__FILE__) . '../templates/view_pill_reminder.php';
    return view_pill_reminder();
}

add_shortcode('sign-in_shortcode','customsignin');

function customsignin()
{
    ob_start();
    require plugin_dir_path(__FILE__) . '../auth/signin.php';
    return singin();
}

add_shortcode('sign-up_shortcode','customsigup');

function customsigup()
{
    ob_start();
    require plugin_dir_path(__FILE__) . '../auth/signup.php';
    return singup();
}

// deactive the pages
function pill_reminders_deactivate()
{
    $slugs = ['pill_reminder', 'add_pill_reminder', 'pill_reminder_details', 'view_pill_reminder','sign-in','sign-up'];
    foreach ($slugs as $slug) {
        $page = get_page_by_path($slug);
        if ($page)
            wp_delete_post($page->ID, true);
    }
    // pill_reminders_remove_table();
    flush_rewrite_rules();
}

// -------------logout page--------------------
function pill_reminders_create_primary_menu_with_all_pages() {
    $menu_name = 'Primary Menu';

    $menu = wp_get_nav_menu_object($menu_name);
    $menu_id = $menu ? $menu->term_id : wp_create_nav_menu($menu_name);

    $pages_to_add = [
        'sign-in'              => 'Sign In',
        'pill_reminder'        => 'Pill Reminder',
        'add_pill_reminder'    => 'Add Pill Reminder',
        'view_pill_reminder'   => 'View Pill Reminder',
        'pill_reminder_details'=> 'Pill Reminder Details',
    ];

    foreach ($pages_to_add as $slug => $title) {
        $page = get_page_by_path($slug);
        if ($page) {
            // Check if already in menu
            $items = wp_get_nav_menu_items($menu_id);
            $exists = false;
            foreach ($items as $item) {
                if ($item->object_id == $page->ID) {
                    $exists = true;
                    break;
                }
            }

            if (!$exists) {
                wp_update_nav_menu_item($menu_id, 0, [
                    'menu-item-title'     => $title,
                    'menu-item-object'    => 'page',
                    'menu-item-object-id' => $page->ID,
                    'menu-item-type'      => 'post_type',
                    'menu-item-status'    => 'publish',
                ]);
            }
        }
    }

    // Assign menu to Astra Primary location
    $locations = get_theme_mod('nav_menu_locations') ?: [];
    $locations['primary'] = $menu_id;
    set_theme_mod('nav_menu_locations', $locations);
}

// Dynamic: Sign In to Logout when logged in
add_filter('wp_nav_menu_objects', 'pill_reminders_dynamic_signin_logout', 10, 2);

function pill_reminders_dynamic_signin_logout($items, $args) {
    if ($args->theme_location !== 'primary') {
        return $items;
    }

    $new_items = [];
    foreach ($items as $item) {
        if (stripos($item->title, 'Sign In') !== false || strpos($item->url, '/sign-in') !== false) {
            if (is_user_logged_in()) {
                $logout = clone $item;
                $logout->title = 'Logout';
                $logout->url   = wp_logout_url(home_url('/pill_reminder/'));
                $new_items[] = $logout;
            } else {
                $new_items[] = $item;
            }
        } else {
            $new_items[] = $item;
        }
    }
    return $new_items;
}